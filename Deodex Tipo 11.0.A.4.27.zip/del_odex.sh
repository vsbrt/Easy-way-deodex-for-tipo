#!/sbin/sh

rm -rf /system/app/*.odex
rm -rf /system/framework/*.odex
exit 0
